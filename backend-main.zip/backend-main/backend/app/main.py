from app.models.prediction import Prediction
from app.models import User, Prediction
from fastapi import FastAPI

from app.database import Base, engine
from app.models import User
from app.routes.auth import router as auth_router

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AfriSafe AI API",
    version="1.0.0"
)

app.include_router(auth_router)


@app.get("/")
def root():
    return {
        "message": "Welcome to AfriSafe AI API"
    }


@app.get("/health")
def health():
    return {
        "status": "healthy"
    }
from app.routes.predict import router as predict_router
app.include_router(auth_router)
app.include_router(predict_router)
