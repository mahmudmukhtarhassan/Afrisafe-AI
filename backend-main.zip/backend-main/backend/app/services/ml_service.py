import joblib
import pandas as pd
from pathlib import Path

MODEL_PATH = Path(__file__).resolve().parent.parent.parent / "models" / "model.pkl"

model = joblib.load(MODEL_PATH)


def preprocess(payload):

    symptoms = payload.assessment.symptoms

    feature = {
        "age": payload.patient.age,

        "gender_male": 1 if payload.patient.gender.lower() == "male" else 0,

        "gender_female": 1 if payload.patient.gender.lower() == "female" else 0,

        "duration_days": payload.assessment.durationDays,

        "recent_bites": int(payload.assessment.recentMosquitoBites),

        "recent_travel": int(payload.assessment.recentTravel),

        "taken_malaria_drugs": int(payload.assessment.takenMalariaDrugs),

        "fever": 0,
        "headache": 0,
        "chills": 0,
        "sweating": 0,
        "fatigue": 0,
        "nausea_vomiting": 0,
        "muscle_pain": 0,
        "joint_pain": 0,
        "loss_of_appetite": 0,
        "diarrhea": 0,
    }

    mapping = {
        "fever": "fever",
        "headache": "headache",
        "chills": "chills",
        "sweating": "sweating",
        "fatigue": "fatigue",
        "nausea": "nausea_vomiting",
        "vomiting": "nausea_vomiting",
        "muscle pain": "muscle_pain",
        "joint pain": "joint_pain",
        "loss of appetite": "loss_of_appetite",
        "diarrhea": "diarrhea"
    }

    for symptom in symptoms:
        s = symptom.lower().strip()

        if s in mapping:
            feature[mapping[s]] = 1

    return pd.DataFrame([feature])


def predict(payload):

    X = preprocess(payload)

    prediction = model.predict(X)[0]

    probability = model.predict_proba(X)[0][1]

    return prediction, probability
