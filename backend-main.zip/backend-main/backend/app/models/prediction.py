from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

from app.database import Base


class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    prediction = Column(String(50), nullable=False)

    risk = Column(String(30), nullable=False)

    confidence = Column(Float, nullable=False)

    recommendation = Column(String(500))

    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
