from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.models.prediction import Prediction

from app.schemas.prediction import (
    PredictionRequest,
    PredictionResponse
)

from app.security import get_current_user

from app.services.ml_service import predict

router = APIRouter(
    prefix="/predict",
    tags=["Prediction"]
)


@router.post("", response_model=PredictionResponse)
def malaria_prediction(
    payload: PredictionRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    prediction, probability = predict(payload)

    confidence = round(probability * 100, 2)

    if prediction == 1:

        result = "Positive"

        risk = "High"

        recommendation = "Visit the nearest health facility immediately."

        advice = [
            "Take malaria test.",
            "Drink enough water.",
            "Do not self-medicate."
        ]

    else:

        result = "Negative"

        risk = "Low"

        recommendation = "Continue monitoring symptoms."

        advice = [
            "Sleep under mosquito net.",
            "Drink enough water.",
            "Visit hospital if symptoms worsen."
        ]

    history = Prediction(
        user_id=current_user.id,
        prediction=result,
        risk=risk,
        confidence=confidence,
        recommendation=recommendation
    )

    db.add(history)

    db.commit()

    return {
        "prediction": result,
        "risk": risk,
        "confidence": confidence,
        "recommendation": recommendation,
        "advice": advice
    }
    from fastapi import Depends
from app.dependencies import get_current_user
from app.models.user import User
