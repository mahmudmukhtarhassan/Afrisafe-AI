from typing import List
from pydantic import BaseModel


class PatientData(BaseModel):
    age: int
    gender: str
    state: str
    lga: str = ""


class AssessmentData(BaseModel):
    symptoms: List[str]
    durationDays: int
    recentMosquitoBites: bool
    recentTravel: bool
    takenMalariaDrugs: bool


class PredictionRequest(BaseModel):
    patient: PatientData
    assessment: AssessmentData


class PredictionResponse(BaseModel):
    prediction: str
    risk: str
    confidence: float
    recommendation: str
    advice: List[str]
