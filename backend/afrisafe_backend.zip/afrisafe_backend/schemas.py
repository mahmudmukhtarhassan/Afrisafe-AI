"""
schemas.py
Pydantic v2 request/response models used across the API.
"""
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


# ---------------------------------------------------------------------------
# Auth / User schemas
# ---------------------------------------------------------------------------
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: Optional[str] = Field(default=None, max_length=255)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit")
        if not any(c.isalpha() for c in v):
            raise ValueError("Password must contain at least one letter")
        return v


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: EmailStr
    full_name: Optional[str] = None
    created_at: datetime


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class TokenData(BaseModel):
    user_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Assessment / Prediction schemas
# ---------------------------------------------------------------------------
class SymptomInput(BaseModel):
    """
    Flexible symptom payload for the malaria triage model.

    `symptoms` holds the raw feature -> value mapping (e.g. {"fever": 1,
    "headache": 1, "age": 34, "temperature": 39.2, ...}). The ml_service
    aligns and orders these values against feature_names.pkl at inference
    time, so the frontend does not need to know the exact feature order.
    """
    symptoms: Dict[str, Any] = Field(
        ...,
        description="Mapping of symptom/feature name to value (0/1, numeric, or category).",
        examples=[{
            "fever": 1,
            "chills": 1,
            "headache": 1,
            "vomiting": 0,
            "muscle_pain": 1,
            "fatigue": 1,
            "age": 29,
            "temperature": 38.9,
        }],
    )
    patient_name: Optional[str] = Field(default=None, max_length=255)

    @field_validator("symptoms")
    @classmethod
    def not_empty(cls, v: Dict[str, Any]) -> Dict[str, Any]:
        if not v:
            raise ValueError("symptoms payload cannot be empty")
        return v


class PredictionResponse(BaseModel):
    probability: float = Field(..., ge=0.0, le=1.0, description="Model probability of malaria (0-1)")
    prediction_label: str = Field(..., description="Binary/class label predicted by the model")
    triage_level: str = Field(..., description="e.g. Low, Medium, High, Emergency")
    confidence: float = Field(..., ge=0.0, le=1.0)
    recommendations: List[str]
    saved_to_history: bool = False
    assessment_id: Optional[str] = None


class AssessmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    user_id: Optional[str] = None
    symptoms_data: Dict[str, Any]
    prediction_result: float
    triage_level: str
    recommendation: Optional[str] = None
    created_at: datetime


class AssessmentHistoryResponse(BaseModel):
    total: int
    items: List[AssessmentOut]


# ---------------------------------------------------------------------------
# System / misc schemas
# ---------------------------------------------------------------------------
class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    feature_count: Optional[int] = None
    environment: str


class ErrorResponse(BaseModel):
    detail: str
