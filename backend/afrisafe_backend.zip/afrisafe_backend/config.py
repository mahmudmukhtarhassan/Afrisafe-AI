"""
config.py
Central application configuration using Pydantic v2 settings management.
All values can be overridden via environment variables or a .env file.
"""
from functools import lru_cache
from pathlib import Path
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent


class Settings(BaseSettings):
    # --- General ---
    APP_NAME: str = "Afrisafe AI"
    API_V1_PREFIX: str = "/api/v1"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True

    # --- Security / JWT ---
    SECRET_KEY: str = Field(
        default="CHANGE_ME_IN_PRODUCTION_afrisafe_secret_key",
        description="Secret key used to sign JWT tokens. Override in production.",
    )
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours

    # --- Database ---
    DATABASE_URL: str = f"sqlite:///{BASE_DIR / 'afrisafe.db'}"

    # --- ML Model Artifacts ---
    MODEL_PATH: Path = BASE_DIR / "Model" / "malaria_model.pkl"
    FEATURE_NAMES_PATH: Path = BASE_DIR / "Model" / "feature_names.pkl"

    # --- CORS ---
    CORS_ORIGINS: List[str] = [
        "http://localhost",
        "http://localhost:3000",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:8000",
        "*",
    ]

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    """Cached settings instance so the .env file is only parsed once."""
    return Settings()


settings = get_settings()
