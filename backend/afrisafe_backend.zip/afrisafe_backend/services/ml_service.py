"""
services/ml_service.py
Loads the trained malaria triage model + its feature schema, and exposes
a clean `predict()` interface that aligns arbitrary symptom dictionaries
to the exact feature vector the model expects.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np

from config import settings

logger = logging.getLogger("afrisafe.ml_service")


class ModelLoadError(RuntimeError):
    """Raised when the model or feature-name artifacts cannot be loaded."""


class MLService:
    """
    Wraps the malaria classifier and its feature schema.

    Usage:
        ml_service = MLService()
        ml_service.load()                      # call once, at startup
        result = ml_service.predict(symptoms)  # per-request inference
    """

    def __init__(self, model_path: Path = settings.MODEL_PATH, features_path: Path = settings.FEATURE_NAMES_PATH):
        self.model_path = Path(model_path)
        self.features_path = Path(features_path)
        self.model: Any = None
        self.feature_names: List[str] = []
        self._loaded: bool = False

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------
    def load(self) -> None:
        """
        Load the pickled model and feature-name list from disk.

        Designed to be called once inside the FastAPI lifespan startup.
        Failures are logged but do not crash the app -- `/health` will
        report `model_loaded: false` and `/predict` will return a 503
        instead of taking the whole API down.
        """
        try:
            if not self.model_path.exists():
                raise ModelLoadError(f"Model file not found at {self.model_path}")
            if not self.features_path.exists():
                raise ModelLoadError(f"Feature names file not found at {self.features_path}")

            self.model = joblib.load(self.model_path)
            feature_names = joblib.load(self.features_path)

            # feature_names.pkl may be a list, tuple, numpy array, or pandas Index
            self.feature_names = list(feature_names)
            self._loaded = True
            logger.info(
                "Malaria model loaded successfully with %d features.", len(self.feature_names)
            )
        except Exception as exc:  # noqa: BLE001 - we want to catch & log any load failure
            self._loaded = False
            logger.error("Failed to load ML model artifacts: %s", exc)

    @property
    def is_loaded(self) -> bool:
        return self._loaded and self.model is not None

    # ------------------------------------------------------------------
    # Feature alignment
    # ------------------------------------------------------------------
    def _align_features(self, symptoms: Dict[str, Any]) -> np.ndarray:
        """
        Build a single-row feature vector in the exact order expected by
        the trained model. Missing features default to 0; unknown keys in
        the input are ignored (but logged for visibility).
        """
        unknown_keys = set(symptoms.keys()) - set(self.feature_names)
        if unknown_keys:
            logger.debug("Ignoring unrecognized symptom keys: %s", unknown_keys)

        row: List[float] = []
        for feature in self.feature_names:
            value = symptoms.get(feature, 0)
            try:
                row.append(float(value))
            except (TypeError, ValueError):
                # Handle simple categorical / boolean strings gracefully
                if isinstance(value, str) and value.strip().lower() in {"yes", "true", "y"}:
                    row.append(1.0)
                elif isinstance(value, str) and value.strip().lower() in {"no", "false", "n"}:
                    row.append(0.0)
                else:
                    row.append(0.0)
        return np.array(row, dtype=float).reshape(1, -1)

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------
    def predict(self, symptoms: Dict[str, Any]) -> Tuple[float, str]:
        """
        Run inference and return (probability_of_malaria, predicted_label).

        Raises:
            ModelLoadError: if the model isn't loaded.
        """
        if not self.is_loaded:
            raise ModelLoadError("ML model is not loaded. Check server startup logs.")

        X = self._align_features(symptoms)

        # Prefer predict_proba when available for a calibrated probability;
        # fall back to a hard predict() output otherwise.
        if hasattr(self.model, "predict_proba"):
            proba = self.model.predict_proba(X)[0]
            # Assume binary classification where index 1 == positive/malaria class
            probability = float(proba[1]) if len(proba) > 1 else float(proba[0])
        else:
            raw_pred = self.model.predict(X)[0]
            probability = float(raw_pred)

        predicted_label = "malaria_positive" if probability >= 0.5 else "malaria_negative"
        return probability, predicted_label

    def get_feature_count(self) -> Optional[int]:
        return len(self.feature_names) if self._loaded else None


# Singleton instance shared across the app, initialized during lifespan startup.
ml_service = MLService()
