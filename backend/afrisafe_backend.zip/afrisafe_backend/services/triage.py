"""
services/triage.py
Converts a raw model probability into a human-facing triage level and a
set of tailored, actionable recommendations.
"""
from typing import Any, Dict, List, Tuple

# Thresholds are deliberately centralized here so they can be tuned without
# touching endpoint code.
TRIAGE_THRESHOLDS: List[Tuple[float, str]] = [
    (0.85, "Emergency"),
    (0.65, "High"),
    (0.35, "Medium"),
    (0.0, "Low"),
]

RECOMMENDATIONS: Dict[str, List[str]] = {
    "Emergency": [
        "Seek immediate emergency medical care or go to the nearest hospital now.",
        "Do not wait for symptoms to worsen -- severe malaria can progress rapidly.",
        "If available, request a rapid diagnostic test (RDT) or blood smear immediately.",
        "Keep the patient hydrated and monitor consciousness while arranging transport.",
    ],
    "High": [
        "Visit a clinic or hospital within the next few hours for testing and evaluation.",
        "Request a malaria rapid diagnostic test (RDT) or microscopy blood smear.",
        "Monitor temperature and symptoms closely; seek emergency care if they worsen.",
        "Avoid self-medicating with antimalarials without a confirmed diagnosis.",
    ],
    "Medium": [
        "Schedule a medical consultation within the next 24 hours.",
        "Get tested for malaria, especially if you're in or recently traveled to an endemic area.",
        "Rest, stay hydrated, and monitor your temperature regularly.",
        "Watch for worsening symptoms such as confusion, difficulty breathing, or persistent vomiting.",
    ],
    "Low": [
        "Symptoms suggest a lower likelihood of malaria, but continue monitoring.",
        "Stay hydrated and rest; consider a routine check-up if symptoms persist beyond 48 hours.",
        "Use protective measures (bed nets, repellents) to reduce further mosquito exposure.",
        "Seek medical care promptly if new or worsening symptoms develop.",
    ],
}


def classify_triage(probability: float) -> str:
    """Map a probability in [0, 1] to a triage level string."""
    for threshold, level in TRIAGE_THRESHOLDS:
        if probability >= threshold:
            return level
    return "Low"


def get_recommendations(triage_level: str) -> List[str]:
    return RECOMMENDATIONS.get(triage_level, RECOMMENDATIONS["Low"])


def build_triage_result(probability: float) -> Dict[str, Any]:
    """
    Convenience helper combining classification + recommendations +
    a simple confidence score (distance from the decision boundary,
    normalized to [0, 1]).
    """
    triage_level = classify_triage(probability)
    confidence = round(abs(probability - 0.5) * 2, 4)  # 0 = uncertain, 1 = fully confident
    return {
        "triage_level": triage_level,
        "confidence": confidence,
        "recommendations": get_recommendations(triage_level),
    }
