"""
scripts/generate_dummy_model.py

OPTIONAL DEV UTILITY -- generates placeholder Model/malaria_model.pkl and
Model/feature_names.pkl so the API can be smoke-tested end-to-end before
the real trained artifacts are dropped in. Replace these with your actual
trained model + feature list for production use.

Run from the backend root:
    python scripts/generate_dummy_model.py
"""
from pathlib import Path

import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression

FEATURE_NAMES = [
    "fever",
    "chills",
    "headache",
    "vomiting",
    "muscle_pain",
    "fatigue",
    "sweating",
    "nausea",
    "age",
    "temperature",
]

MODEL_DIR = Path(__file__).resolve().parent.parent / "Model"
MODEL_DIR.mkdir(exist_ok=True)


def main() -> None:
    rng = np.random.default_rng(42)
    n_samples = 500
    X = rng.integers(0, 2, size=(n_samples, len(FEATURE_NAMES) - 2))
    ages = rng.integers(1, 90, size=(n_samples, 1))
    temps = rng.uniform(36.0, 41.0, size=(n_samples, 1))
    X = np.hstack([X, ages, temps])

    # Rough synthetic rule: more symptoms + higher temp => higher malaria risk
    risk_score = X[:, :8].sum(axis=1) / 8 + (X[:, 9] - 36.0) / 5
    y = (risk_score > np.median(risk_score)).astype(int)

    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)

    joblib.dump(model, MODEL_DIR / "malaria_model.pkl")
    joblib.dump(FEATURE_NAMES, MODEL_DIR / "feature_names.pkl")
    print(f"Dummy model + feature names written to {MODEL_DIR}")


if __name__ == "__main__":
    main()
