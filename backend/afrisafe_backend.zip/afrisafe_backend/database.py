"""
database.py
SQLAlchemy engine, session factory, and declarative base.
Works out of the box with SQLite and can be pointed at PostgreSQL by
changing DATABASE_URL in the environment (e.g. postgresql+psycopg2://...).
"""
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from config import settings

# SQLite requires this connect_arg when used with multiple threads (FastAPI's
# threadpool for sync endpoints). It's a no-op for other database backends.
connect_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(
    settings.DATABASE_URL,
    connect_args=connect_args,
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    """Base class for all ORM models."""
    pass


def get_db() -> Generator:
    """FastAPI dependency that yields a DB session and ensures it is closed."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create all tables. Called once during application startup (lifespan)."""
    import models  # noqa: F401  (ensures models are registered on Base metadata)
    Base.metadata.create_all(bind=engine)
