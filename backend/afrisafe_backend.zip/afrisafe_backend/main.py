"""
main.py
Afrisafe AI -- FastAPI backend entry point.

Run with:
    uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""
import logging
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

import models
from auth import (
    create_access_token,
    get_current_user,
    get_current_user_optional,
    hash_password,
    verify_password,
)
from config import settings
from database import get_db, init_db
from schemas import (
    AssessmentHistoryResponse,
    AssessmentOut,
    ErrorResponse,
    HealthResponse,
    PredictionResponse,
    SymptomInput,
    Token,
    UserCreate,
    UserLogin,
    UserOut,
)
from services.ml_service import ModelLoadError, ml_service
from services.triage import build_triage_result

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("afrisafe.main")


# ---------------------------------------------------------------------------
# Lifespan: load DB tables + ML model once at startup
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Afrisafe AI backend...")
    init_db()
    ml_service.load()
    if not ml_service.is_loaded:
        logger.warning(
            "ML model did not load. /assessment/predict will return 503 until "
            "Model/malaria_model.pkl and Model/feature_names.pkl are available."
        )
    yield
    logger.info("Shutting down Afrisafe AI backend...")


app = FastAPI(
    title=settings.APP_NAME,
    description="AI-powered malaria triage and risk assessment API.",
    version="1.0.0",
    lifespan=lifespan,
)

# ---------------------------------------------------------------------------
# CORS -- allow the static frontend (assessment.html, login.html, result.html)
# to call the API from any local dev origin.
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

API = settings.API_V1_PREFIX


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------
@app.get(f"{API}/health", response_model=HealthResponse, tags=["System"])
async def health_check() -> HealthResponse:
    return HealthResponse(
        status="ok",
        model_loaded=ml_service.is_loaded,
        feature_count=ml_service.get_feature_count(),
        environment=settings.ENVIRONMENT,
    )


# ---------------------------------------------------------------------------
# Auth: register / login
# ---------------------------------------------------------------------------
@app.post(
    f"{API}/auth/register",
    response_model=Token,
    status_code=status.HTTP_201_CREATED,
    responses={400: {"model": ErrorResponse}},
    tags=["Auth"],
)
async def register(payload: UserCreate, db: Session = Depends(get_db)) -> Token:
    existing = db.query(models.User).filter(models.User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")

    user = models.User(
        email=payload.email,
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_access_token(subject=user.id)
    return Token(access_token=token, user=UserOut.model_validate(user))


@app.post(
    f"{API}/auth/login",
    response_model=Token,
    responses={401: {"model": ErrorResponse}},
    tags=["Auth"],
)
async def login(payload: UserLogin, db: Session = Depends(get_db)) -> Token:
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    token = create_access_token(subject=user.id)
    return Token(access_token=token, user=UserOut.model_validate(user))


@app.post(
    f"{API}/auth/token",
    response_model=Token,
    include_in_schema=False,
    tags=["Auth"],
)
async def login_oauth2_form(
    form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)
) -> Token:
    """OAuth2-compatible token endpoint (useful for Swagger UI's 'Authorize' button)."""
    return await login(UserLogin(email=form_data.username, password=form_data.password), db)


@app.get(f"{API}/auth/me", response_model=UserOut, tags=["Auth"])
async def read_current_user(current_user: models.User = Depends(get_current_user)) -> UserOut:
    return UserOut.model_validate(current_user)


# ---------------------------------------------------------------------------
# Assessment: predict + history
# ---------------------------------------------------------------------------
@app.post(
    f"{API}/assessment/predict",
    response_model=PredictionResponse,
    responses={422: {"model": ErrorResponse}, 503: {"model": ErrorResponse}},
    tags=["Assessment"],
)
async def predict_malaria(
    payload: SymptomInput,
    db: Session = Depends(get_db),
    current_user: Optional[models.User] = Depends(get_current_user_optional),
) -> PredictionResponse:
    if not ml_service.is_loaded:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Prediction model is currently unavailable. Please try again later.",
        )

    try:
        probability, predicted_label = ml_service.predict(payload.symptoms)
    except ModelLoadError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc))
    except Exception as exc:  # noqa: BLE001
        logger.exception("Prediction failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Prediction failed: {exc}",
        )

    triage = build_triage_result(probability)

    assessment_id: Optional[str] = None
    saved = False

    # Persist to history: always saved (user_id nullable for guests), matching
    # the "save history if authenticated" requirement while still keeping a
    # record for analytics/audit purposes.
    try:
        assessment = models.Assessment(
            user_id=current_user.id if current_user else None,
            symptoms_data=payload.symptoms,
            prediction_result=probability,
            triage_level=triage["triage_level"],
            recommendation="; ".join(triage["recommendations"]),
        )
        db.add(assessment)
        db.commit()
        db.refresh(assessment)
        assessment_id = assessment.id
        saved = True
    except Exception:  # noqa: BLE001
        db.rollback()
        logger.exception("Failed to persist assessment history")

    return PredictionResponse(
        probability=round(probability, 4),
        prediction_label=predicted_label,
        triage_level=triage["triage_level"],
        confidence=triage["confidence"],
        recommendations=triage["recommendations"],
        saved_to_history=saved and current_user is not None,
        assessment_id=assessment_id,
    )


@app.get(
    f"{API}/assessment/history",
    response_model=AssessmentHistoryResponse,
    tags=["Assessment"],
)
async def get_assessment_history(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
    limit: int = 50,
    offset: int = 0,
) -> AssessmentHistoryResponse:
    query = (
        db.query(models.Assessment)
        .filter(models.Assessment.user_id == current_user.id)
        .order_by(models.Assessment.created_at.desc())
    )
    total = query.count()
    items = query.offset(offset).limit(min(limit, 200)).all()

    return AssessmentHistoryResponse(
        total=total,
        items=[AssessmentOut.model_validate(item) for item in items],
    )


@app.get(f"{API}/assessment/history/{{assessment_id}}", response_model=AssessmentOut, tags=["Assessment"])
async def get_assessment_detail(
    assessment_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
) -> AssessmentOut:
    assessment = (
        db.query(models.Assessment)
        .filter(models.Assessment.id == assessment_id, models.Assessment.user_id == current_user.id)
        .first()
    )
    if not assessment:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assessment not found")
    return AssessmentOut.model_validate(assessment)


# ---------------------------------------------------------------------------
# Root
# ---------------------------------------------------------------------------
@app.get("/", tags=["System"])
async def root():
    return {
        "message": f"{settings.APP_NAME} API is running.",
        "docs": "/docs",
        "health": f"{API}/health",
    }
