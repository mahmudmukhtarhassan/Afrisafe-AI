# Afrisafe AI -- Backend

Production-ready FastAPI backend for the Afrisafe AI malaria triage platform.

## Structure

```
├── main.py             # FastAPI entry point, routes, CORS, lifespan startup
├── config.py            # Pydantic settings (env-driven)
├── database.py           # SQLAlchemy engine / SessionLocal / Base
├── models.py             # SQLAlchemy ORM models (User, Assessment)
├── schemas.py            # Pydantic v2 request/response models
├── auth.py               # JWT + bcrypt password hashing utilities
├── services/
│   ├── ml_service.py     # Loads malaria_model.pkl / feature_names.pkl, runs inference
│   └── triage.py         # Probability -> triage level + recommendations
├── Model/
│   ├── malaria_model.pkl       # <- replace with your trained model
│   └── feature_names.pkl       # <- replace with your feature list
├── scripts/
│   └── generate_dummy_model.py # optional: generates a placeholder model for local testing
└── requirements.txt
```

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then edit SECRET_KEY for production
```

Drop your trained artifacts into `Model/malaria_model.pkl` and
`Model/feature_names.pkl` (a list of the feature names the model was
trained on, in order). If you don't have real artifacts yet, generate a
placeholder set for smoke-testing:

```bash
python scripts/generate_dummy_model.py
```

## Run

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

- Interactive API docs: http://localhost:8000/docs
- Health check: http://localhost:8000/api/v1/health

## Key endpoints

| Method | Path                              | Auth      | Description                               |
|--------|------------------------------------|-----------|--------------------------------------------|
| GET    | `/api/v1/health`                  | none      | Status + model-loaded flag                |
| POST   | `/api/v1/auth/register`           | none      | Create account, returns JWT               |
| POST   | `/api/v1/auth/login`              | none      | Login, returns JWT                        |
| GET    | `/api/v1/auth/me`                 | required  | Current user profile                      |
| POST   | `/api/v1/assessment/predict`      | optional  | Run malaria triage prediction             |
| GET    | `/api/v1/assessment/history`      | required  | List the current user's past assessments  |
| GET    | `/api/v1/assessment/history/{id}` | required  | Fetch a single assessment                 |

`POST /api/v1/assessment/predict` works for both guests and logged-in
users. Send an `Authorization: Bearer <token>` header to have the result
associated with your account and retrievable from `/history`.

### Example: predict

```bash
curl -X POST http://localhost:8000/api/v1/assessment/predict \
  -H "Content-Type: application/json" \
  -d '{"symptoms": {"fever": 1, "chills": 1, "headache": 1, "age": 29, "temperature": 39.2}}'
```

The `symptoms` object accepts any subset of feature keys -- `ml_service.py`
aligns them to `feature_names.pkl`'s exact order and fills any missing
features with 0, so the frontend doesn't need to know the model's internal
feature ordering.

## Notes on production hardening

- Set a strong, random `SECRET_KEY` via environment variable before deploying.
- Point `DATABASE_URL` at PostgreSQL for production, e.g.
  `postgresql+psycopg2://user:pass@host:5432/afrisafe`.
- Tighten `CORS_ORIGINS` in `config.py` to your actual frontend domain(s)
  instead of `*`.
- Password hashing uses `bcrypt` directly (not `passlib[bcrypt]`) to avoid
  a known compatibility crash between passlib's backend detection and
  recent bcrypt releases.
